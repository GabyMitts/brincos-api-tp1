select * from produto;


